var jokeText = "\u2022Mala Aai, papa ani akhya khandanchi shappate mi hechyavr kadhich swataha trade ghenar nahi\n\u2022I will only follow rathor\n\u2022jr mi ghetla tr mi lvkarach bankkrupt hoil. karan mi aj jinkel udya jinkel pn kadhitri sagle paishe harnar. This is 1000000% sure.\n\u2022I will Follow Money management rules while trading\n\u2022Ani mi hya paishyachya mohat nai padnar till month end karan he paishe ajun majhya account mde nahi alet.\n\u2022Very Imp I will keep patience till month end bcoz 'thembe thembe tale sache'"
       // const jokeElement = document.getElementById('jokeElement');

        // jokeElement.innerHTML = jokeText;
        alert(jokeText)
